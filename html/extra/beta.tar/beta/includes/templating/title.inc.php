	<div id="logo" style="display:block;">
		<div style="float:left;">
			<span style="font-size:4em;float:left;color:#0CF;">[</span>
		</div>
		<div style="float:left;text-align:center;margin-top:.75em;">
			<span style="font-size:1.75em;display:block;clear:both;margin:auto;font-family:Arial,Helvetica,sans-serif;font-weight:600;">Texas</span>
			<span style="font-size:.75em;display:block;clear:both;margin:auto;font-family:Arial,Helvetica,sans-serif;font-weight:600;">Test Problem Server</span>
		</div>
		<div style="float:left;">
			<span style="font-size:4em;float:left;color:#0CF;">]</span>
		</div>
	</div>
