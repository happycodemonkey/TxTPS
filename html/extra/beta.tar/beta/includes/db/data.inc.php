<?php
/*
 File: data.inc.php
 Author: James Kneeland
 Purpose: Generator/Collection database abstraction
 Note: This file includes [common/properties].inc.php . Make sure not to include them, or use include_once. 
*/
include_once("common.inc.php");


/*
 Returns an ordered list of products.
  $start : Initial offset
 $limit : Total number of results to return. 
 */
function product_list($col = 'id', $start = 0, $limit = 20){
  $query = sprintf(" SELECT product.id, product.identifier, product.created, generator.name as gen_name, generator.id as generator_id, collection.name as col_name,  collection.collection_id as collection_id FROM product LEFT JOIN generator ON product.generator_id = generator.id  LEFT JOIN collection ON generator.collection_id = collection.collection_id ORDER BY %s LIMIT %s, %s",
				"product.". $col,
				$start,
				$limit);
  $result =  db_query($query, true);

  if(count($result) != 0){
    return $result; 
  }else{
    return false;
  }
}


/*
 Returns an ordered list of products.
  $start : Initial offset
 $limit : Total number of results to return. 
 */
function product_list_by_collection($col = 'id', $start = 0, $limit = 20, $collection_id){
  $query = sprintf("SELECT product.id, product.identifier, product.created, generator.name as gen_name, generator.id as generator_id, collection.name as col_name,  collection.collection_id as collection_id FROM product LEFT JOIN generator ON product.generator_id = generator.id  LEFT JOIN collection ON generator.collection_id = collection.collection_id WHERE collection.collection_id = '%s' ORDER BY %s LIMIT %s, %s",
				$collection_id,
				"product.". $col,
				$start,
				$limit);
  $result =  db_query($query, true);

  if(count($result) != 0){
    return $result; 
  }else{
    return false;
  }
}

/*
 Returns an ordered list of products.
  $start : Initial offset
 $limit : Total number of results to return. 
 */
function product_list_by_generator($col = 'id', $start = 0, $limit = 20, $generator_id){
  $query = sprintf("SELECT product.id, product.identifier, product.created, generator.name as gen_name, generator.id as generator_id, collection.name as col_name,  collection.collection_id as collection_id FROM product LEFT JOIN generator ON product.generator_id = generator.id  LEFT JOIN collection ON generator.collection_id = collection.collection_id WHERE generator_id = '%s' ORDER BY %s LIMIT %s, %s",
				$generator_id,
				"product.". $col,
				$start,
				$limit);
  $result =  db_query($query, true);

  if(count($result) != 0){
    return $result; 
  }else{
    return false;
  }
}


/*
 Returns an ordered list of products.
  $start : Initial offset
 $limit : Total number of results to return. 
 */
function product_list_by_user($col = 'id', $start = 0, $limit = 20, $user_id){
  $query = sprintf(" SELECT product.id, product.identifier, product.created, generator.name as gen_name, collection.name as col_name FROM product LEFT JOIN generator ON product.generator_id = generator.id  LEFT JOIN collection ON generator.collection_id = collection.collection_id WHERE product.user_id = %s ORDER BY %s LIMIT %s, %s",
				$user_id,
				"product.". $col,
				$start,
				$limit);
  $result =  db_query($query, true);

  if(count($result) != 0){
    return $result; 
  }else{
    return false;
  }
}




/**
Inserts a request into the database for generation using the arguments passed
**/
function product_generate($generator_id, $user_id, $arguments){
	$query = sprintf("INSERT INTO product (generator_id,user_id,producttype_id,arguments) VALUES('%s','%s','%s','%s')",
					$generator_id,
					$user_id,
					$product_id,
					serialize($arguments));
	$result =  db_query($query, true);

	if(count($result) != 0){
	    return $result[0]; //should only be one, as product_id is unique
	}else{
	    return false;
	}
}

/**
Called by the generator routine to update the product's information in the database after generation.

This function updates the timestamp so that the product will not be regenerated. 
**/
function product_store($product_id, $identifier){
	$query = sprintf("UPDATE product set product.identifier='%s', product.created=NOW() WHERE id = '%s'",
					$identifier,
					$product_id);
	$result =  db_query($query);

	if(count($result) != 0){
	    return $result[0]; //should only be one, as product_id is unique
	}else{
	    return false;
	}
}

/**
Returns information including the identifier of the product specified
**/
function product_get($identifier){
	$query = sprintf("SELECT *, product.id, product.identifier, product.created, generator.name as gen_name, collection.name as col_name FROM product LEFT JOIN generator ON product.generator_id = generator.id  LEFT JOIN collection ON generator.collection_id = collection.collection_id WHERE product.identifier='%s'",
					$identifier);
	$result =  db_query($query, true);

	if(count($result) != 0){
	    return $result[0]; //should only be one, as product_id is unique
	}else{
	    return false;
	}
}

function product_queue(){
	$query = sprintf("SELECT * from product  WHERE product.created IS NULL");

	$result =  db_query($query, true);
	return $result;
}

function product_count(){
	$query = sprintf("SELECT count(id) as count FROM product");
	$result =  db_query($query, true);
	return $result[0]['count'];
}
?>
