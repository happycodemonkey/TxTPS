<?
include_once("../includes/db/users.inc.php");
include_once("../includes/db/generators.inc.php");
include_once("../includes/db/data.inc.php");
require_once("../includes/classes/Security.class.php");


//make sure user is logged in and an admin
$security = Security::getInstance();
if(!$security->isLoggedIn() || $security->getClassName() !== "Admin"){
  Security::forward("../login.php");
 }



$max_rows = 6; //max number of rows to display for each segment

function decodeSize( $bytes ){
    $types = array( 'B', 'KB', 'MB', 'GB', 'TB' );
    for( $i = 0; $bytes >= 1024 && $i < ( count( $types ) -1 ); $bytes /= 1024, $i++ );
    return( round( $bytes, 2 ) . " " . $types[$i] );
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="../css/main.css" />
<style type="text/css">
th,td{
	padding:.125em .5em .125em .5em;
}
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
<script src="../src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:300, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("../includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("../includes/templating/adminmenu.inc.php"); ?>
	</div>
	<div id="content">
		<h1>Server Adminstration</h1>

		<div id="genforms">
			<div id="UserPanel">
				<div class="panelHeader">User Management</div>
				<div class="panelContent">
				<?php
				$user_list = user_list();
				if($user_list != false){
				?>
				<table>
				<tbody><tr>
					<th>Username</th>
					<th>User&nbsp;Class</th>
					<th>E-Mail</th>
					<th>Modify</th>
					<th>Delete</th><th>
				</th></tr><tr>
				</tr>
				<?php
					$count = 0;
					foreach($user_list as $user){
							if($count < $max_rows){
								$count++;
							}else{
								break;
							}

					?>
						<tr>
							<td><?php echo $user['firstname'] . "&nbsp;" . $user['lastname'] ?></td>
							<td><?php echo $user['class']?></td>
							<td><?php echo $user['email']?></td>
							<td><form method="post" action="user_modify.php"><input name="id" value="<?php echo $user['id']?>" type="hidden"><input type="hidden" name="action" value="edit"><input value="Modify" type="submit"></form></td>
							<td><form method="post" action="user_modify.php"><input name="id" value="<?php echo $user['id']?>" type="hidden"><input type="hidden" name="action" value="delete"><input value="Delete" type="submit"></form></td>
						</tr>
					<?php
					} //end of foreach
					?>
					</tbody></table>
					<p><span style="float:left;margin:5px;"><form action="user.php"><input type="submit" value="View Users"></form></span><span style="float:left;margin:5px;"><form action="user_modify.php"><input type="submit" value="Add Users"></form></span></p>
					<?php
				}else{
					?>
					<p>No users found. Would you like to <a href="user_modify.php">add</a> one?</p>
					<?php
				}
				?>
				</div>
			</div>
			<div id="GenPanel">
				<div class="panelHeader">Collections/Generators</div>
				<div class="panelContent">
				<?php
					$collection_list = generator_collection_list();
					if($collection_list == false){
					  echo "<p><b>No collections found</b></p>";
					}else{
					?>
					<div>
						<table>
						<tbody><tr>
							<th>Name</th>
					                <th>#&nbsp; Generators</th>
							<th>List</th>
							<th>Modify</th>
							<th>Delete</th><th>
						</th></tr><tr>
						</tr>
						<?php
						$count = 0;
						foreach($collection_list as $row){
							if($count < $max_rows){
								$count++;
							}else{
								break;
							}
						?>
						<tr>
							<td><?php echo $row["name"]?></td>
							<td><?php echo $row["count"]?></td>
							<td><form method="post" action="generator.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input value="List" type="submit"></form></td>
							<td><form method="post" action="collection_modify.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input type="hidden" name="action" value="edit"><input value="Modify" type="submit"></form></td>
							<td><form method="post" action="collection_modify.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input type="hidden" name="action" value="delete"><input value="Delete" type="submit"></form></td>
						</tr>
						<?php 
						}//end for loop
						?>
					</tbody></table>
					<?php
					} //end else
					?>
					<p><span style="float:left;margin:5px;"><form action="collection.php"><input type="submit" value="View Collections"></form> </span><span style="float:left;margin:5px;"><form action="collection_modify.php"><input type="submit" value="Add Collections"></form></span></p>
				</div>
			</div>
			<div id="HealthPanel">
				<div class="panelHeader">Server Health</div>
				<div class="panelContent">
					<p><b>Uptime:</b> <?php echo shell_exec("uptime");?></p>
					<p><b>Free Space:</b> <?php echo decodeSize(disk_free_space("/")); ?></p>
					<p><b>Total Space:</b> <?php echo decodeSize(disk_total_space("/")); ?></p>
					<p><b>Matix Count:</b> <?php echo product_count(); ?></p>
				</div>
			</div>
			<div id="MiscPanel">
				<div class="panelHeader">Miscellaneous</div>
				<div class="panelContent">
					<p><a href="visualization.php">Visualization</a></p>
					<p><a href="statistics.php">Statistics</a></p>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
