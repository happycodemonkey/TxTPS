<?php
if(!empty($_POST)){
error_reporting(E_ALL);

$example = '';
$arguments = '';
switch($_POST['type']){

	case "ex1":
	$example = "ex1";
	if(isset($_POST['n']) AND is_numeric($_POST['n'])){
		$arguments = " -n " . $_POST['n'];
	}
	break;

	case "ex12":
	$example = "ex12";
	if(isset($_POST['n']) AND is_numeric($_POST['n'])){
		$arguments .= " -n " . $_POST['n'];
	}
	if(isset($_POST['m']) AND is_numeric($_POST['m'])){
		$arguments .= " -m " . $_POST['m'];
	}
	break;
	
	case "ex32":
	$example = "ex32";
	break;
}
	$shell_command = "./ksp/" . $example . $arguments;
	putenv("LD_LIBRARY_PATH=/opt/intel/compiler9.1/cc/lib/:/opt/intel/compiler9.1/fc/lib/");
	$output = shell_exec($shell_command);

	// filename that the user gets as default
	$download_file = "Output.mtx";
	 
	// send headers
	header('Cache-control: private');
	header('Content-Type: application/octet-stream'); 
	//header('Content-Length: '.filesize($local_file));
	header('Content-Disposition: filename='.$download_file);
 
	// flush content
	flush();
 
 
	echo $output;
	exit();
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:150, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<style type="text/css">
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="menu">
		<ul>
			<li><a class="menulink" href="index.php">Home</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="generator.php">Generators</a></li>
			<li><a class="menulink" href="pickup.php">Pick up File</a></li>
		</ul>
	</div>
	<div id="titlebar">
		<img src="title.png"  alt="Test Problem Server" /></div>
	<div id="content">
	<h3>PETSc KSP Examples</h3>
		<div id="genforms">
			<div id="ex1">
				<div class="panelHeader">Example 1</div>
				<div class="panelContent">
				<p>A tridiagonal linear system	matrix</p>
				<form method="post">
					<p>Size (n) <input type="text" name="n"/></p>
					<input type="hidden" name="type" value="ex1" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
			<div id="ex12Panel">
				<div class="panelHeader">Example 12</div>
				<div class="panelContent">
				<p>Nonlinear driven cavity with multigrid and pseudo timestepping 2d.</p>
				<form method="post">
					<p>Size (x dim) <input type="text" name="m"/></p>
					<p>Size (y dim) <input type="text" name="n"/></p>
					<input type="hidden" name="type" value="ex12" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
			<div id="ex32Panel">
				<div class="panelHeader">Example 32</div>
				<div class="panelContent">
				<p>Model multi-physics solver. Modified from example 19</p>
				<form method="post">
					<input type="hidden" name="type" value="ex32" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
