<?php 
abstract class Collection{


}
?>