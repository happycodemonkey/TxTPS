<?php 
abstract class Collection{


}
?> 