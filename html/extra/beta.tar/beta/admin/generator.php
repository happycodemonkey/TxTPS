<?
include_once("../includes/db/generators.inc.php");
require_once("../includes/classes/Security.class.php");

$security = Security::getInstance();
if(!$security->isLoggedIn()){
  Security::forward("../login.php");
 }



$generator_list = null;
$start = 0;
$limit = 20;
if(isset($_REQUEST['start']) && is_numeric($_REQUEST['start'])){
	$start = $_REQUEST['start'];
}
if(isset($_REQUEST['limit']) && is_numeric($_REQUEST['limit'])){
	$limit = $_REQUEST['limit'];
}
if(isset($_REQUEST['id']) && is_numeric($_REQUEST['id'])){
	$generator_list = generator_list("id",$start,$limit, $_REQUEST['id']);
}else{
	$generator_list = generator_list("id",$start,$limit);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/main.css">
<style type="text/css">
th,td{
	padding:.25em 1em .25em 1em;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Problem Server</title>
</head><body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("../includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("../includes/templating/adminmenu.inc.php"); ?>
	</div>
	
	<div id="content">
		<h1>Generator Management</h1>

		<?php
		if(($generator_list) !== false){
			?>
			<div>
				<table>
				<tbody><tr>
					<th>Name</th>
					<th>Collection</th>
                  			<th>Output&nbsp;Format</th>
				</th></tr><tr>
				</tr><tr>
					<?php
					foreach($generator_list as $row){
					?>
					<tr>
						<td><?php echo $row["name"]?></td>
						<td><?php echo $row["collection"]?> </td>
					        <td><?php echo $row["format"]?> </td>
					</tr>
					<?php 
					}//end for loop
					?>
				</tr>
				</tbody></table>
			<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">First</a></span>
			<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">Previous</a></span>
			<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Last</a></span>
			<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Next</a></span>
			</div>
			<?php
		}else{//end of if(false)
			?>
			<div>
				<p><b>No collections found</b></p>
			</div>
			<?php
		}//end of else
		?>
	</div>
	<div id="footer">
	</div>
</div>
</body></html>
