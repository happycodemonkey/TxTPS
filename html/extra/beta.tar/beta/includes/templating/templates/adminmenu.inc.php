		<ul>
			<li><a class="menulink" href="index.php">Control Panel</a></li>
			<li><a class="menulink" href="user.php">Users</a></li>
			<li><a class="menulink" href="collection.php">Collections</a></li>
			<li><a class="menulink" href="data.php">Data</a></li>
		</ul>
		
		
