
<?php
require_once("./includes/classes/Generator.class.php");
require_once("./includes/classes/Collection.class.php");

$id = $_REQUEST['id'];
$generator = Generator::loadByID($id);
$title = "Generator";

$description = $generator->getDescription();
$subtitle = $generator->getName();;

   
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
<head>
<link  rel="stylesheet" type="text/css" href="./css/main.css" />
<style type="text/css">
th,td{
	padding:.25em 1em .25em 1em;
}
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<script src="./src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:200, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>

	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="#">Accounts</a>
			<li><a class="sidemenulink" href="#">Support</a>
			<li><a class="sidemenulink" href="#">Contact</a>
		</ul>
	</div>
	<div id="content">
        <h1><?php echo $title . " : " . $subtitle; ?></h1>

	<h2>Description</h2>
	<p><?php echo $description; ?></p>
	
	<h2>Build</h2>
	<p> You must be logged in before attempting to submit requests for matrix builds</p>
	
	<form action="build.php"> 
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <input type="submit" value="Build Matrix">
        </form>
	<h2>Recent History</h2>
	
     
	</div>
	<div id="login">
            <?php require("./includes/templating/login.inc.php"); ?> 
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
