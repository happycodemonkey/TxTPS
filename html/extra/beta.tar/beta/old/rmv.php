<?php
$path '/tmp/install';
if (file_exists(dirname($path))) {
    foreach (new DirectoryIterator(dirname($path)) as $file) {
        if (true === $file->isFile()) {
            unlink($file->getPathName());
        }
    }
    rmdir(dirname($path));
}
?>
