<?php

echo "<h3>Testing PETSC Loading</h3>";
echo "<p><b>Command: <b>/opt/modules/bin/modulecmd csh avail</b></p>";
echo "<p>". passthru("/opt/modules/bin/modulecmd csh avail 2>&1")."</p>";

echo "<p><b>Command: <b>/opt/modules/bin/modulecmd bash avail</b></p>";
echo "<p>". passthru("/opt/modules/bin/modulecmd bash avail 2>&1")."</p>";

//echo passthru('whoami');
//echo "<br />";
//echo passthru('env');
?>
