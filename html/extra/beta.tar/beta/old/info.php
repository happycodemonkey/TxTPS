<?php
 phpinfo();
?>	