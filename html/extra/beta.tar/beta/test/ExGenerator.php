<?php 
class ExGenerator extends Generator{

	
	execute(bo)
}
?>