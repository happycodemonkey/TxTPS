<?
require_once("./includes/util/security.inc.php");
require_once("./includes/db/data.inc.php");
$product_list = null;
$start = 0;
$limit = 20;
$sort = "id";


/* Require the user to be logged in */
if(!$auth->is_logged_in()){
	$auth->forward("login.php");
}




if(isset($_REQUEST['start']) && is_numeric($_REQUEST['start'])){
	$start = $_REQUEST['start'];
}
if(isset($_REQUEST['limit']) && is_numeric($_REQUEST['limit'])){
	$limit = $_REQUEST['limit'];
}
if(isset($_REQUEST['col']) && preg_match("/[a-z0-9\.]+/i",($_REQUEST['col']))){
	$sort = $_REQUEST['col'];
}
$product_list = product_list_by_user($sort,$start,$limit, $auth->get_user_id());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="accounts.php">Accounts</a>
			<li><a class="sidemenulink" href="support.php">Support</a>
			<li><a class="sidemenulink" href="format.php">Formats</a>
			<li><a class="sidemenulink" href="search.php">Search</a>
			<li><a class="sidemenulink" href="pickup.php">Download</a>
		</ul>
	</div>
	<div id="content">
		<h1>Generation History</h1>
		<?php
		if(($product_list) !== false){
			?>
			<div>
				<table>
				<tbody><tr>
					<th>Identifier</th>
					<th>Collection</th>
					<th>Generator</th>
					<th>Creation</th>
				</tr><tr>
				</tr>
					<?php
					foreach($product_list as $row){
					?>
					<tr><?php
						if(isset($row["identifier"]) && strlen($row["identifier"]) > 0){
						 ?><td><a href="matrix.php?id=<?php echo $row["identifier"]?>"><?php echo $row["identifier"]?></a></td><?php
						}else{
						?><td>N/A</td><?php
						}
						?>
						<td><?php echo $row["col_name"]?> </td>
						<td><?php echo $row["gen_name"]?> </td>
						<?php
						if(isset($row["creation"]) && strlen($row["creation"]) > 0){
						 ?><td><?php echo $row["creation"]?></td><?php
						}else{
						?><td>Building</td><?php
						}
						?>
					</tr>
					<?php 
					}//end for loop
					?>
				</tbody></table>
			<span style="margin: 0.5em; display: inline-block; float: left;"><a href="matrix.php?start=0&limit=<?php echo $limit;?>&sort=<?php echo $sort;?>">First</a></span>
			<span style="margin: 0.5em; display: inline-block; float: left;"><a href="matrix.php?start=<?php echo (($start - $limit)>=0)?($start-limit):0;?>&limit=<?php echo $limit;?>&sort=<?php echo $sort;?>">Previous</a></span>
			<span style="margin: 0.5em; display: inline-block; float: right;"><a href="matrix.php?start=<?php echo $start;?>&limit=<?php echo $limit;?>&sort=<?php echo $sort;?>">Last</a></span>
			<span style="margin: 0.5em; display: inline-block; float: right;"><a href="matrix.php?start=<?php echo ($start + $limit);?>&limit=<?php echo $limit;?>&sort=<?php echo $sort;?>">Next</a></span>
			</div>
			<?php
		}else{//end of if(false)
			?>
			<div>
				<p><b>No matrices found in history</b></p>
				<p>Have you tried <a href="collection.php">generating some?</a></p>
			</div>
			<?php
		}//end of else
		?>
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
