<?php
if(!empty($_POST)){
error_reporting(E_ALL);

echo "You selected the ". $_POST['type'] . " problem. ";

echo "<p>";
var_dump($_POST);
echo "</p>";


$shell_command = "/opt/matlab/bin/matlab -r  -nosplash -r \"cd /var/www/html/beta/nlevp/private , butterfly(23) , exit\"  2>&1";
$output = shell_exec($shell_command);
echo "<pre>$output</pre>";


echo `ls -lart`;


//call matlab
/*shell_exec('matlab -r ./nlevp/private/bicycle');

$descriptorspec = array(
   0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
   1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
);

$cwd = './nlevp/private';
$process = proc_open('ls -a', $descriptorspec, $pipes);

if (is_resource($process)) {
	echo "Valid ";
    // $pipes now looks like this:
    // 0 => writeable handle connected to child stdin
    // 1 => readable handle connected to child stdout
    // Any error output will be appended to /tmp/error-output.txt

    fwrite($pipes[0], '2 + 3');
    fclose($pipes[0]);

    echo stream_get_contents($pipes[1]);
    fclose($pipes[1]);

    // It is important that you close any pipes before calling
    // proc_close in order to avoid a deadlock
    $return_value = proc_close($process);

    echo "command returned $return_value\n";
}
//echo $result;
*/

//call the function with the provided args

//save the result to a file

//send the user to pick up their file



echo $result;
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:350, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<style type="text/css">
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="menu">
		<ul>
			<li><a class="menulink" href="index.php">Home</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="generator.php">Generators</a></li>
			<li><a class="menulink" href="pickup.php">Pick up File</a></li>
		</ul>
	</div>
	<div id="titlebar">
		<img src="title.png"  alt="Test Problem Server" /></div>
	<div id="content">
	<h3>Nonlinear Eigenvalue Problems (NLEVP)</h3>
		<div id="genforms">
			<div id="acousticwave1DPanel">
				<div class="panelHeader">1D Acoustic Wave</div>
				<div class="panelContent">
				<p>
			        Constructs an N-by-N
					quadratic matrix polynomial lambda^2*M + lambda*D + K that arises
					from the discretization of a 1D acoustic wave equation.
					The damping matrix has the form Z^(-1)*D, where
					D is a low rank real symmetric matrix and the scalar parameter Z is
					the impedance (posibly complex).
					The default values are N = 10 and Z = 1.

				</p>
				<p>This problem has the properties pep, qep, real, symmetric, parameter-dependent, scalable.</p>
					<form method="post">
						<input type="hidden" name="type" value="acoustic_wave_1d" />
						<p>N * <input name="args[]" type="text" /> Z * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
			</div>
			<div id="acousticwave2DPanel">
				<div class="panelHeader">2D Acoustic Wave</div>
				<div class="panelContent">
				<p>
			        Constructs a quadratic matrix polynomial lambda^2*M + lambda*D + K that arises from
					the discretization by finite elements of a two-dimensional acoustic
					wave equation. The coefficient matrices are N-by-N with
					N = N1*(N1-1), H  = 1/N1 being the mesh size.  The damping matrix has the
					form Z^(-1)*D, where D is a low rank real symmetric matrix and
					the scalar parameter Z is the impedance (possibly complex).
					The default values are N1 = 6 (N = 30) and Z = 1.

				</p>
				<p>This problem has the properties pep, qep, real symmetric, parameter-dependent, scalable.</p>
					<form method="post">
						<input type="hidden" name="type" value="acoustic_wave_2d" />
						<p>N1 * <input name="args[]" type="text" /> Z * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
			</div>			
			<div id="bicyclePanel">
				<div class="panelHeader">Bicycle</div>
				<div class="panelContent">
				<p>
			        Constructs a 2-by-2 QEP (from the Whipple bicycle model) matrix
					polynomial lambda^2*M + lambda*v*C + K0 + v^2*K2 arising in the
					study of the dynamic behaviour of a bicycle.
					Velocity (default 5) is the forward speed in m/s.
				</p>
				<p>This problem has the properties pep, qep, real, parameter_dependent.</p>
					<form method="post">
						<input type="hidden" name="type" value="bicycle" />
						<p>Velocity * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
			</div>
			<div id="bilbyPanel">
				<div class="panelHeader">Bilby</div>
				<div class="panelContent">
				<p>
			        Constructs a 5-by-5 quadratic matrix
					polynomial lambda^2*A + lambda*B + C arising in a
					quasi-birth-death process model of the population of the greater bilby,
					an endangered Australian marsupial.  A and C are both singular.
					BETA is a parameter (default: 0.5).
					The matrices are returned in a cell array: COEFFS = {C, B, A}.
				</p>
				<p>This problem has the properties pep, qep, real, parameter-dependent.</p>
					<form method="post">
						<input type="hidden" name="type" value="acoustic_wave_1d" />
						<p>Beta * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
			</div>
			<div id="butterflyPanel">
				<div class="panelHeader">Butterfly</div>
				<div class="panelContent">
				<p>
					Quartic matrix polynomial with T-even structure.
				</p>
					Generates a M^2-by-M^2 quartic matrix polynomial
					P(\lambda) = lambda^4*A_4 + lambda^2*A_3 +  lambda^2*A_2 + lambda*A_1 + A_0
					for which A_4 and A_2 are real and symmetric and
					A_3 and A_1 are real and skew-symmetric (assuming C is real).
					The spectrum has a butterfly shape.
					The default is M = 8.  C is an 10-by-1 vector of parameters.
				</p>
				<p>	
					This problem has the properties pep, real, parameter-dependent, T-even,
					scalable.

				</p>
					<form method="post">
						<input type="hidden" name="type" value="butterfly" />
						<p>M <input name="args[]" type="text" /> C <input name="args[]" type="text"/></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="closedloopPanel">
				<div class="panelHeader">Closed Loop</div>
				<div class="panelContent">
				<p>
					Constructs a 2-by-2 quadratic
					matrix polynomial lambda^2*A2 + lambda*A1 + A0 associated with a
					closed-loop control system with feedback gains 1 and 1+ALPHA.
					For 0 < ALPHA < 0.875 all eigenvalues lie inside the unit disc.
					The default is ALPHA = 1. 
				</p>
				<p>	
					 This problem has the properties pep, qep, real, parameter_dependent.
				</p>
					<form method="post">
						<input type="hidden" name="type" value="closed_loop" />
						<p>Alpha * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="concretePanel">
				<div class="panelHeader">Concrete</div>
				<div class="panelContent">
				<p>
					Generates the coefficient matrices of a
					quadratic matrix polynomial lambda^2*C + lambda*B + A arising in a
					model of a concrete structure supporting a machine assembly.
					This problem is complex symmetric and has dimension 2472.
					The matrices are sparse and returned in a
					cell array: COEFFS = {A, B, C}.
					</p>
					<p>
					C = mass matrix, real diagonal, low rank.
					B = viscous damping matrix, purely imaginary
					and diagonal, B = i*C_v, low rank.
					A = stiffness + uniform hysteretic damping
					matrix, A = (1 + i*mu)*K, mu = 0.04.
				</p>
				<p>	
					 This problem has the properties pep, qep, symmetric, parameter-dependent, sparse.
				</p>
					<form method="post">
						<input type="hidden" name="type" value="concrete" />
						<p>Mu * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="dbeamPanel">
				<div class="panelHeader">Damped Beam</div>
				<div class="panelContent">
					<p>
						Constructs an N-by-N (N = 2*NELE)
						quadratic matrix polynomial lambda^2*M + lambda*D + K from a finite
						element model of a beam clamped at both ends with a damper in the middle.
						NELE (default NELE = 100) is the number of finite elements (even).
						Half of the eigenvalues of the problem are pure imaginary
						and are eigenvalues of the undamped problem (D = 0).					
					</p>
			
					<p>	
						 This problem has the properties pep, qep, real, symmetric, scalable.
					</p>
					<form method="post">
						<input type="hidden" name="type" value="damped_beam" />
						<p>NELE * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="diracPanel">
				<div class="panelHeader">Dirac</div>
				<div class="panelContent">
					<p>
					Generates the coefficient matrices
					of a quadratic matrix polynomial lambda^2*A + lambda*B + C of dimension
					N + M.  The spectrum
					of this matrix polynomial is the second order spectrum of the
					Dirac operator with an electric Coulombic potential,
					relative to the subspace generated by the Hermite functions of odd order.
					The potential is attractive and of strength ALPHA where
					-SQRT(3)/2 < ALPHA < 0.
					The constant KAPPA (which should be an integer) corresponds
					to a radially symmetric decomposition of the space into partial wave
					subspaces.  In this decomposition, the operator acts on
					L^2(0,\infty)xL^2(0,\infty). The matrix truncation is found by
					picking N Hermite functions in the first component and M in the second
					component. By default N = M = 40, KAPPA = -1, and ALPHA = -1/2.		
					</p>
			
					<p>	
						 This problem has the properties pep, qep, real, symmetric, parameter-dependent, scalable. This function is unvectorized and hence very slow for large N + M.
					</p>
					<form method="post">
						<input type="hidden" name="type" value="dirac" />
						<p>N * <input name="args[]" type="text" /> 	M * <input name="args[]" type="text" /></p>
						<p>Alpha * <input name="args[]" type="text" /> 	Kappa * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="lstringPanel">
				<div class="panelHeader">Loaded String</div>
				<div class="panelContent">
					<p>
					Generates an N-by-N rational
					matrix function A - lambda*B + lambda/(lambda-sigma)*C with sigma = KAPPA/m
					arising in the finite element discretization of a boundary problem
					describing the eigenvibration of a string with a load of mass m
					attached by an elastic spring of stiffness KAPPA.
					The default values are N = 20, KAPPA = 1.
					</p>
			
					<p>	This problem has the properties rep, qep, real, symmetric,parameter_dependent, scalable.					</p>
					<form method="post">
						<input type="hidden" name="type" value="loaded_string" />
						<p>N * <input name="args[]" type="text" /></p>
						<p>Kappa * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
				<div id="orrsommerfeld">
				<div class="panelHeader">Orr Sommerfeld</div>
				<div class="panelContent">
					<p>
					Quartic PEP arising from Orr-Sommerfeld equation.
					COEFFS = NLEVP('orr_sommerfeld',N,R,W) returns the coefficients of
					an N-by-N quartic matrix polynomial
					P(lambda) = lambda^4*A4+lambda^3*A3+lambda^2*A2+ lambda*A1 + A0
					arising from the spatial stability analysis of the Orr-Sommerfeld equation.
					The parameter R is the Reynolds number of the problem and w the frequency.
					The default values are N = 64, R = 5772, W = 0.26943.
					</p>
			
					<p>	This problem has the properties pep, parameter-dependent, scalable.					</p>
					<form method="post">
						<input type="hidden" name="type" value="orr_sommerfeld" />
						<p>N * <input name="args[]" type="text" /></p>
						<p>R * <input name="args[]" type="text" /></p>
						<p>W * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="powerplantPanel">
				<div class="panelHeader">Power Plant</div>
				<div class="panelContent">
					<p>
					Generates the matrices of an 8-by-8
					quadratic matrix polynomial lambda^2*M+lambda*D+K arising in the study of
					the dynamic behaviour of a nuclear power plant. The matrices D and M are
					real symmetric and K is defined as K = (1+i*mu)K0 with K0 real symmetric.
					The parameter MU describes hysteretic damping added to the model.
					The default value for MU is 0.2.
					</p>
					<p>
					This problem has the properties pep, qep, symmetric, parameter_dependent.
					</p>
					<form method="post">
						<input type="hidden" name="type" value="power_plant" />
						<p>Mu * [Default 0.2] <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
			<div id="sleeperPanel">
				<div class="panelHeader">Sleeper</div>
				<div class="panelContent">
					<p>
					Generates an NxN proportionally damped
					quadratic matrix polynomial Q(lambda) = lambda^2 A2 + lambda*A1 + A0
					arising from the analysis of a railtrack resting on sleepers.
					The matrices are returned in a cell array: COEFFS = {A0, A1, A2}.
					The exact eigenvalues and eigenvectors are known and are returned as
					SOL.EVAL and SOL.EVEC.  The default size of the problem is N = 10.
					</p>
					<form method="post">
						<input type="hidden" name="type" value="sleeper" />
						<p>N * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
