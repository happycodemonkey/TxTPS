<?php 
include_once("./includes/db/generators.inc.php");
$collection_list = generator_collection_list();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./css/main.css">
<style type="text/css">
th,td{
	padding:0 1em 0 1em;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Problem Server</title>
</head><body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="accounts.php">Accounts</a>
			<li><a class="sidemenulink" href="support.php">Support</a>
			<li><a class="sidemenulink" href="contact.php">Contact</a>
		</ul>
	</div>
	<div id="content">
		<h1>Generator Collections</h1>

		<div>
		
		</div>
		<?php 
		if($collection_list == false){
		  echo "<p><b>No collections found</b></p>";
		}else{
		?>
		<div>
			<table>
			<tbody><tr>
				<th>Collection Name</th>
				<th>#&nbsp;Generators</th>
				<th>Generator List</th>
			</th></tr><tr>
			</tr>
			<?php
			foreach($collection_list as $row){
			//TODO Implement selection of additonal information in the DB code
			?>
			<tr>
				<td><?php echo $row["name"]?></td>
				<td><?php echo $row["count"]?> </td>
				<td><form method="get" action="collection.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input value="List Generator" type="submit"></form></td>
			</tr>
			<?php 
			}//end for loop
			?>
		</tbody></table>
		<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">First</a></span>
		<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">Previous</a></span>
		<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Last</a></span>
		<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Next</a></span>
		</div>
		<?php
		}//end else
		?>
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?>
	</div>
	<div id="footer">
	</div>
</div>
</body></html>
