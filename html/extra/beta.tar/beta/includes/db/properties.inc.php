<?
/*
 File: properties.inc.php
 Author: James Kneeland
 Purpose: Database connection information
 Note: ROT13 is obviously not real security, but this will atleast prevent the database information from being stored
 in plain text format. 
*/
define("DB_SERVER",str_rot13("ybirgg.gnpp.hgrknf.rqh."));
define("DB_PASSWORD",str_rot13("crnepr"));
define("DB_USERNAME",str_rot13("CUC"));
define("DB_DATABASE",str_rot13("GCF"));
?>
