		<ul>
			<li><a class="menulink" href="index.php">TxTPS</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="inventory.php">Generators</a></li>
			<li><a class="menulink" href="data.php">Matrices</a></li>
			<li><input size="45" type="text" value="Tag or Keywords..." onClick="if(this.value == 'Tag or Keywords...'){this.value='';}" style="border:none;background-color:#EEE;color:#0CF;"></li><li><input type="submit" value="Search" style=""></li>
		</ul>
		
		
