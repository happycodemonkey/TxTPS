<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="signup.php">Sign Up</a>
			<li><a class="sidemenulink" href="support.php">Support</a>
			<li><a class="sidemenulink" href="contact.php">Contact</a>
		</ul>
	</div>
	<div id="content">
		<h1>TxTPS Accounts</h1>
		<p>In order to limit the load on the server, we require users to establish an account before
		   they are allowed to build new matrices. Furthermore, you will be able to see your build
		   history for easy reference in the future. </p>
		<p>If you already have a TACC or TeraGrid account, you will soon be able to login directly 
		   with this account in the future. Please continue signing up below, and when this is 
		   implemented, you will be able to migrate your account.</p>
		<p><a href="signup.php">Sign Up for Account</a></p>
		
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
