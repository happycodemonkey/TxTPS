<?php

require_once("./includes/classes/Security.class.php");
require_once("./includes/util/emailer.inc.php");
require_once("./includes/db/generators.inc.php");
require_once("./includes/db/data.inc.php");
require_once("./includes/classes/Generator.class.php");
require_once("./includes/classes/Collection.class.php");

/* Require the user to be logged in */

$security = Security::getInstance();
if(!$security->isLoggedIn()){
  Security::forward("login.php");
};

$action = $_REQUEST['action'];
$step = $_REQUEST['step'];
$gen_id =  $_REQUEST['id'];

$subtitle = "Build Matrix";

$gen_info = generator_details_get($gen_id);
$title = $gen_info["name"];
$description = $gen_info['description'];



function build(){
  global $security;
  global $step;
  global $gen_id;

  
	$args = array();
		$keys = array_keys($_REQUEST);
		foreach($keys as $key){
			if(strpos($key,"arg_") === 0){
				$name = substr($key,4);
				$args[$name] = $_REQUEST[$key];
			}
	}
  
	$generator = Generator::loadByID($gen_id);
	$valid = true;
	$errors = null;
	if($step == 1){
		$valid = $generator->validate($args, $errors); 
	}
  
  
 
  //gather list of arguments needed
  $arg_list = generator_arguments_get($gen_id);
  
  if((!$valid && $step == 1) || (($step == 0 || !isset($step)) AND isset($gen_id))) { //display form for input   ?>
   
   
   <h2>Description</h2>
   <p><?php echo $generator->getDescription(); ?></p>
		
   <h2>Variables</h2>
   <table>
   <form method="post">
   <input type="hidden" name="step" value="1">
   <input type="hidden" name="id"	value="<?php echo $gen_id?>">
		<?php
		if(count($arg_list) > 0){
		  echo "<p>Please enter the required arguments for the matrix.</p>";
		   if(!$valid){
			echo "<h2><b>ERROR: $errors</b></h2>";
		   }  

			foreach($arg_list as $arg){
				$name = $arg['name'];
				$type = $arg['type'];
				$variable = $arg['variable'];
				$value = ($type == "BOOLEAN")?array_key_exists($variable, $args):$args[$variable];
				$description = $arg['description'];
				$optional = $arg['optional'];
				$options = $arg['options'];
			
			
			
				if($type == "STRING" || $type == "INTEGER" || $type == "FLOAT" || $type == "DOUBLE"){
				?>
					<tr>
						<td><b><?php echo $name?>&nbsp;<?php echo($optional)?"":"*";?></b></td><td><input type="text"  value="<?php echo $value;?>" name="arg_<?php echo $variable?>"></td>
					</tr>
					<tr><td colspan="2"><em><?php echo "&nbsp;&nbsp;&nbsp;" .$description; ?></em></td></tr>

				<?php
				}elseif($type == "BOOLEAN"){
				?>
					<tr>
						<td><b><?php echo $name?>&nbsp;<?php echo($optional)?"":"*";?></b></td><td><input type="checkbox"  value="<?php echo ($value)?"true":"false";?>" name="arg_<?php echo $variable?>"></td>
					</tr>
					<tr><td colspan="2"><em><?php echo "&nbsp;&nbsp;&nbsp;" . $description; ?></em></td></tr>
				<?php
				}
				elseif($type == "SELECT"){
				?>
					<tr>
						<td><b><?php echo $name?>&nbsp;<?php echo($optional)?"":"*";?></b></td><td><select  value="<?php echo $value;?>" name="arg_<?php echo $variable?>">
						
						<?php
						foreach(unserialize($options) as $option){
							echo "<option value=\"$option\">$option</option>";
						}
						?>
						
						</select></td>
					</tr>
					<tr><td colspan="2"><em><?php echo "&nbsp;&nbsp;&nbsp;" . $description; ?></em></td></tr>
				<?php
				}
			}
		}else{
			echo "<p> This generator has no inputs</p>";
		}
		?>
		<tr>
			<td><input type="submit"  value="Submit for Generation"></td> 
		</tr>
   </form>
   </table>
   <?php
  }  elseif($step == 1 && $valid){
		?> 
		<p>Your request has been received. You will be notified by email when it is built.  </p>
		<?php
	        //$generator->build($args, "/tmp/testing/");
	        
	        product_generate($_REQUEST['id'],$security->getUser()->getID(),$args);
                emailer_send_job_received($security->getUser()->getId(),"");
		echo "<p>Additionally, an email has been sent to your address.</p>";
		


  }else{
	?>
		<p>I'm sorry, I was unable to process that request. </p>
	<?php
  }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
<head>
<link  rel="stylesheet" type="text/css" href="./css/main.css" />
<style type="text/css">
th,td{
	padding:.25em 1em .25em 1em;
}
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<script src="./src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:200, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>

	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="#">Accounts</a>
			<li><a class="sidemenulink" href="#">Support</a>
			<li><a class="sidemenulink" href="#">Contact</a>
		</ul>
	</div>
	<div id="content">
        <h1><?php echo $subtitle . " : " . $title; ?></h1>

        <?php
			build();
			
		
		?>
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?> 
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
