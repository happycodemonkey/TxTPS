<?php
abstract class Generator{

	function argList(){
	
	}

}
?>