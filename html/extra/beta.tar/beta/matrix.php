<?
include_once("./includes/db/data.inc.php");
include_once("./includes/db/generators.inc.php");

$id = substr($_REQUEST['id'],0,6);
if(isset($_REQUEST['start']) && is_numeric($_REQUEST['start'])){
	$start = $_REQUEST['start'];
}
$info = product_get($id);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="accounts.php">Accounts</a>
			<li><a class="sidemenulink" href="support.php">Support</a>
			<li><a class="sidemenulink" href="format.php">Formats</a>
			<li><a class="sidemenulink" href="search.php">Search</a>
			<li><a class="sidemenulink" href="pickup.php">Download</a>
		</ul>
	</div>
	<div id="content">
		<?php
		if($info){
			?>
			<h1>Matrix # <?php echo $id; ?></h1>
			<h2>Demographic Information</h2>
				<table>
					<tr>
						<td><b>Collection</b></td>
						<td><a href="generator.php?id=<?php echo $info['collection_id']?>"><?php echo $info['col_name'] ?></a></td>
					</tr>
					<tr>
						<td><b>Generator</b></td>
						<td><a href="build.php?id=<?php echo $info['generator_id']?>"><?php echo $info['gen_name'] ?></td>
					</tr>
				</table>
			<form action="pickup.php" >
				<input type="submit" value="Download">
				<input type="hidden" value="<?php echo $info['identifier']?>" name="id">
			</form>
			<h2>Plots, Graphics, Visualizations</h2>
				<img 
src="plot.php?type=structural&matrix_id=<?php echo $id ?>">
			<h2>Original Generation Arguments</h2>
				<?php
				$args = unserialize($info['arguments']);
				$arg_list = generator_arguments_get($info['generator_id']);
					
				if(count($args) > 0){
					echo "<table>\n";
					echo "<th>Name</th>\n";
					echo "<th>Value</th>\n";
					foreach($args as $key=>$value){
						echo "<tr>\n";
						echo "<td><b>" . $key."</b></td>\n";
						echo "<td>$value</td>\n";
						echo "</tr>\n";
					}
					echo "</table>\n";
				}
				?>
			<h2>Calculated Statistics</h2>
				<p>Todo</p>
		<?php
		}else{
			echo "<h1>Error</h1>\n";
			echo "<p>Matrix # $id could not be found in the database.</p>\n";
		}?>
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
