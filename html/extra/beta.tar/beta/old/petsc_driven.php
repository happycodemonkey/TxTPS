<?php
if(!empty($_POST)){
error_reporting(E_ALL);

$example = '';
switch($_POST['type']){

	case "ex19":
	$example = "ex19";
	break;

	case "ex27":
	$example = "ex27";
	break;
	
	case "ex32":
	$example = "ex32";
	break;
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
<style>
strong{
	color:#00CCFF;
}
</style>
</head>
<body>
<div id="wrapper">
	<div id="menu">
		<ul>
			<li><a class="menulink" href="index.php">Home</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="generator.php">Generators</a></li>
			<li><a class="menulink" href="pickup.php">Pick up File</a></li>
		</ul>
	</div>
	<div id="titlebar">
		<img src="title.png"  alt="Test Problem Server" /></div>
	<div id="content">
		<h3>Problem <?php echo ucwords($example) ?></h3>
		
		<p><strong>Output:</strong></p>
		<?
		$shell_command = "./petsc/" . $example;
		$output = shell_exec($shell_command);
		echo "<pre>$output</pre>";
		?>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
<?php
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:100, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<style type="text/css">
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="menu">
		<ul>
			<li><a class="menulink" href="index.php">Home</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="generator.php">Generators</a></li>
			<li><a class="menulink" href="pickup.php">Pick up File</a></li>
		</ul>
	</div>
	<div id="titlebar">
		<img src="title.png"  alt="Test Problem Server" /></div>
	<div id="content">
	<h3>PETSc Examples</h3>
		<div id="genforms">
			<div id="ex19Panel">
				<div class="panelHeader">Example 19</div>
				<div class="panelContent">
				<p>
			       Nonlinear driven cavity with multigrid in 2d. 
				</p>
				<form method="post">
					<input type="hidden" name="type" value="ex19" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
			<div id="ex27Panel">
				<div class="panelHeader">Example 27</div>
				<div class="panelContent">
				<p>Nonlinear driven cavity with multigrid and pseudo timestepping 2d.</p>
				<form method="post">
					<input type="hidden" name="type" value="ex27" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
			<div id="ex32Panel">
				<div class="panelHeader">Example 32</div>
				<div class="panelContent">
				<p>Model multi-physics solver. Modified from example 19</p>
				<form method="post">
					<input type="hidden" name="type" value="ex32" />
					<p> <input value="Generate" type="submit"/></p>
				</form>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
