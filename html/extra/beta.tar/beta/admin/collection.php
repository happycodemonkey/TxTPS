<?php 
include_once("../includes/db/generators.inc.php");
require_once("../includes/classes/Security.class.php");

//make sure user is logged in and an admin
$security = Security::getInstance();
if(!$security->isLoggedIn() ||  $security->getClassName() !== "Admin"){
  Security::forward("../login.php");
 }




$collection_list = generator_collection_list();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/main.css">
<style type="text/css">
th,td{
	padding:0 1em 0 1em;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Problem Server</title>
</head><body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("../includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("../includes/templating/adminmenu.inc.php"); ?>
	</div>

	<div id="content">
		<h1>Generator Collection Management</h1>

		<div>
		<p>This page allows you to <a href="collection_modify.php">install</a>, modify, delete, and otherwise manage collections of generators on the server.</p><p>
		</p></div>
		<?php 
		if($collection_list == false){
		  echo "<p><b>No collections found</b></p>";
		}else{
		?>
		<div>
			<table>
			<tbody><tr>
				<th>Name</th>
				<th>#&nbsp;Generators</th>
				<th>List</th>
				<th>Edit</th>
				<th>Delete</th>
			</th></tr><tr>
			</tr>
			<?php
			foreach($collection_list as $row){
			//TODO Implement selection of additonal information in the DB code
			?>
			<tr>
				<td><?php echo $row["name"]?></td>
				<td><?php echo $row["count"]?> </td>
				<td><form method="post" action="generator.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input value="List" type="submit"></form></td>
				<td><form method="post" action="collection_modify.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input value="Edit" type="submit"><input type="hidden" name="action" value="edit"></form></td>
				<td><form method="post" action="collection_modify.php"><input name="id" value="<?php echo $row['id']?>" type="hidden"><input value="Delete" type="submit"><input type="hidden" name="action" value="delete"></form></td>
			</tr>
			<?php 
			}//end for loop
			?>
		</tbody></table>
		<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">First</a></span>
		<span style="margin: 0.5em; display: inline-block; float: left;"><a href="#">Previous</a></span>
		<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Last</a></span>
		<span style="margin: 0.5em; display: inline-block; float: right;"><a href="#">Next</a></span>
		</div>
		<?php
		}//end else
		?>
	</div>
	<div id="footer">
	</div>
</div>
</body></html>
