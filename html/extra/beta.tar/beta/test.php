<?php
$file = "/data/install/test/LibMeshTest.php";
require_once("./includes/classes/Collection.class.php");
require_once("./includes/classes/Generator.class.php");
require_once($file);

for($i = 0; $i < 1; $i++){
	$LibMesh = LibMeshTest::getInstance();
	$LibMesh->install($error, $file);
}
?>