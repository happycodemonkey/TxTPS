		<?php
		require_once(dirname(__FILE__) . "/../classes/Security.class.php");
		$security = Security::getInstance();
		if(!$security->isLoggedIn()){
		?>
			<form action="login.php" method="post">
				<ul>
					<li><input size="15" type="text" value="E-Mail Address"  name="email" onClick="this.value='';" style="border:none;background-color:#EEE;color:#0CF;"></li>
					<li><input size="15" type="password" value="password" name="password" onClick="this.value='';" style="border:none; background-color:#EEE;color:#0CF;"></li>
					<li><input type="submit" value="Login" style=""></li>
				</ul>
			</form>
		<?php
		}else{
			echo "<p><h2>" . $security->getUser()->getFirstName() . "</h2></p>";
			echo "<p><h3>" . $security->getUser()->getEmail() ."</h3></p>";
			echo "<p><a class=\"sidemenulink\" href=\"history.php\">History</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class=\"sidemenulink\" href=profile.php>Profile</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class=\"sidemenulink\" href=login.php?logout=true>Logout</a></p>";
		}//end login check
		?>
