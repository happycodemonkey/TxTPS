<?php
if(!empty($_POST)){
error_reporting(E_ALL);

echo "You selected the ". $_POST['type'] . " problem. ";

echo "<p>";
var_dump($_POST);
echo "</p>";


shell_exec('matlab -r ./nlevp/private/bicycle');


//call matlab
/*
$descriptorspec = array(
   0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
   1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
);

$cwd = './nlevp/private';
$process = proc_open('ls -a', $descriptorspec, $pipes);

if (is_resource($process)) {
	echo "Valid ";
    // $pipes now looks like this:
    // 0 => writeable handle connected to child stdin
    // 1 => readable handle connected to child stdout
    // Any error output will be appended to /tmp/error-output.txt

    fwrite($pipes[0], '2 + 3');
    fclose($pipes[0]);

    echo stream_get_contents($pipes[1]);
    fclose($pipes[1]);

    // It is important that you close any pipes before calling
    // proc_close in order to avoid a deadlock
    $return_value = proc_close($process);

    echo "command returned $return_value\n";
}
//echo $result;
*/


passthru("matlab");

//call the function with the provided args

//save the result to a file

//send the user to pick up their file



echo $result;
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="src/rico.js" type="text/javascript"></script>
<script type='text/javascript'>
Rico.loadModule('Accordion');

Rico.onLoad( function() {
  new Rico.Accordion( $$('div.panelHeader'), $$('div.panelContent'),
                      {panelHeight:350, hoverClass: 'mdHover', selectedClass: 'mdSelected'});
});
</script>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<style type="text/css">
.panelHeader{
	font-weight:bold;
	font-size:medium;
	cursor:pointer;
}
.mdHover{
	color:#666;
}
.mdSelected{
	color:#00CCFF;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="menu">
		<ul>
			<li><a class="menulink" href="index.php">Home</a></li>
			<li><a class="menulink" href="about.php">About</a></li>
			<li><a class="menulink" href="generator.php">Generators</a></li>
			<li><a class="menulink" href="pickup.php">Pick up File</a></li>
		</ul>
	</div>
	<div id="titlebar">
		<img src="title.png"  alt="Test Problem Server" /></div>
	<div id="content">
		<h3>PyLith Problems</h3>
		<div id="genforms">
			<div id="acousticwave1DPanel">
				<div class="panelHeader">Blah</div>
				<div class="panelContent">
				<p>
			    </p>
				<p>Blah.</p>
					<form method="post">
						<input type="hidden" name="type" value="acoustic_wave_1d" />
						<p>N * <input name="args[]" type="text" /> Z * <input name="args[]" type="text" /></p>
						<p> <input value="Generate" type="submit"/></p>
					</form>
			</div>
		</div>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
