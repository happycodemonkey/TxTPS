<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link  rel="stylesheet" type="text/css" href="css/main.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Problem Server</title>
</head>
<body>
<div id="wrapper">
	<div id="titlebar">
		<?php include("./includes/templating/title.inc.php"); ?>
	</div>
	<div id="menu">
		<?php include("./includes/templating/menu.inc.php"); ?>
	</div>
	<div id="sidemenu">
		<ul>
			<li><a class="sidemenulink" href="signup.php">Sign Up</a>
			<li><a class="sidemenulink" href="support.php">Support</a>
			<li><a class="sidemenulink" href="contact.php">Contact</a>
		</ul>
	</div>
	<div id="content">
		<h1>Search Results</h1>
		<form method="post">
		<input name="query" size="60" type="text" value="Tag or Keywords..." onClick="if(this.value == 'Tag or Keywords...'){this.value='';}" style="border:none;background-color:#EEE;color:#0CF;"> <input type="submit" value="Search" style="">
		</form>
		<p>Enter keywords above to search by tags, titles, and generator type. </p>
<?php 	if(isset($_REQUEST['query']) AND strlen(trim($_REQUEST['query'])) > 0){


			echo "<h2>Generators / Collections</h2>";

		
			echo "<h2>Matrices</h2>";
		}else{
			
		}
		?>
	</div>
	<div id="login">
		<?php require("./includes/templating/login.inc.php"); ?>
	</div>
	<div id="footer">
	</div>
</div>
</body>
</html>
